var NAVTREE_DATA =
[ [ "com.amazon.device.messaging", "reference/com/amazon/device/messaging/package-summary.html", [ [ "Classes", null, [ [ "ADM", "reference/com/amazon/device/messaging/ADM.html", null, null ], [ "ADMConstants", "reference/com/amazon/device/messaging/ADMConstants.html", null, null ], [ "ADMConstants.LowLevel", "reference/com/amazon/device/messaging/ADMConstants.LowLevel.html", null, null ], [ "ADMMessageHandlerBase", "reference/com/amazon/device/messaging/ADMMessageHandlerBase.html", null, null ], [ "ADMMessageReceiver", "reference/com/amazon/device/messaging/ADMMessageReceiver.html", null, null ] ]
, null ] ]
, null ], [ "com.amazon.device.messaging.development", "reference/com/amazon/device/messaging/development/package-summary.html", [ [ "Classes", null, [ [ "ADMManifest", "reference/com/amazon/device/messaging/development/ADMManifest.html", null, null ] ]
, null ] ]
, null ] ]

;

