var DATA = [
      { id:0, label:"com.amazon.geo.maps", link:"reference/com/amazon/geo/maps/package-summary.html", type:"package" },
      { id:1, label:"com.amazon.geo.maps.GeoPoint", link:"reference/com/amazon/geo/maps/GeoPoint.html", type:"class" },
      { id:2, label:"com.amazon.geo.maps.ItemizedOverlay", link:"reference/com/amazon/geo/maps/ItemizedOverlay.html", type:"class" },
      { id:3, label:"com.amazon.geo.maps.ItemizedOverlay.OnFocusChangeListener", link:"reference/com/amazon/geo/maps/ItemizedOverlay.OnFocusChangeListener.html", type:"class" },
      { id:4, label:"com.amazon.geo.maps.MapActivity", link:"reference/com/amazon/geo/maps/MapActivity.html", type:"class" },
      { id:5, label:"com.amazon.geo.maps.MapController", link:"reference/com/amazon/geo/maps/MapController.html", type:"class" },
      { id:6, label:"com.amazon.geo.maps.MapView", link:"reference/com/amazon/geo/maps/MapView.html", type:"class" },
      { id:7, label:"com.amazon.geo.maps.MapView.LayoutParams", link:"reference/com/amazon/geo/maps/MapView.LayoutParams.html", type:"class" },
      { id:8, label:"com.amazon.geo.maps.MapView.ReticleDrawMode", link:"reference/com/amazon/geo/maps/MapView.ReticleDrawMode.html", type:"class" },
      { id:9, label:"com.amazon.geo.maps.MyLocationOverlay", link:"reference/com/amazon/geo/maps/MyLocationOverlay.html", type:"class" },
      { id:10, label:"com.amazon.geo.maps.Overlay", link:"reference/com/amazon/geo/maps/Overlay.html", type:"class" },
      { id:11, label:"com.amazon.geo.maps.Overlay.Snappable", link:"reference/com/amazon/geo/maps/Overlay.Snappable.html", type:"class" },
      { id:12, label:"com.amazon.geo.maps.OverlayItem", link:"reference/com/amazon/geo/maps/OverlayItem.html", type:"class" },
      { id:13, label:"com.amazon.geo.maps.Projection", link:"reference/com/amazon/geo/maps/Projection.html", type:"class" },
      { id:14, label:"com.amazon.geo.maps.TrackballGestureDetector", link:"reference/com/amazon/geo/maps/TrackballGestureDetector.html", type:"class" }

    ];
